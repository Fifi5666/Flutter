import 'package:flutter/material.dart';

class ListviewScreen extends StatefulWidget {
  const ListviewScreen({super.key});

  @override
  State<ListviewScreen> createState() => _ListviewScreenState();
}

class _ListviewScreenState extends State<ListviewScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("리스트 뷰"),),
      body: Container(
        padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 0),
        child: Center(
          child: ListView.builder(
            itemBuilder: (context, position) {
              return 
                GestureDetector(
                  child: Card(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Image.asset(
                          "image/logo.png",
                          width: 64,
                          height: 64,
                          fit: BoxFit.contain,
                        ),
                        const Text("카드 제목"),
                        const Icon(
                          Icons.arrow_right,
                          size: 32.0,
                          color: Colors.black,
                        ),
                      ],
                    )
                  ),
                  onTap: () {
                    print("카드 클릭!!!");
                    AlertDialog dialog = AlertDialog(
                      content: const Text(
                        "제목은 000 입니다.",
                        style: TextStyle(fontSize: 20.0),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            print("확인 버튼 클릭!");
                            Navigator.of(context).pop();
                          },
                          child: const Text("확인"),
                          )
                      ]
                    );
                    showDialog(
                      context: context,
                      builder: (BuildContext context) => dialog
                      );
                  },
                )
              ;
            },
            itemCount: 10,
          ),
        )
      ),
    );
  }
}